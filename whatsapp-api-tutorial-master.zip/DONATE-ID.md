# DONASI

Merasa terbantu dengan projek ini dan ingin memberi dukungan dengan berdonasi?

[![Donasi dengan PayPal](paypal.svg)](https://www.paypal.me/nrmuhammad)

Teman-teman juga dapat memberikan donasi melalui rekening berikut ini:
- Nama Bank: **Bank Mandiri** [ Kode Bank: 008 ]
- Nomor Rekening: **161-00-0140973-4**
- Nama Penerima: **Nur Muhammad**

Jangan sungkan untuk [hubungi saya melalui Whatsapp](https://wa.me/6287864423038). Misal ingin melakukan konfirmasi terkait dukungan yang diberikan atau hal lainnya.

Terima kasih.
